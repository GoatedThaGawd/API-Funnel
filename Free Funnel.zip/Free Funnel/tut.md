# API Funnel > Faith x OVD

[SETUP]:

Ubuntu:
  > Install screen "apt-get install -y screen"
  > Drag files in your VPS/Server
  > Change the settings inside /settings
  > Give perms "chmod +x ./*"
  > Run the api "screen -dmS api ./api"

CentOs:
  > Install screen "yum install -y screen"
  > Drag files in your VPS/Server
  > Change the settings inside /settings
  > Give perms "chmod +x ./*"
  > Run the api "screen -dmS api ./api"


[DOCS]:

Links:
  http://localhost:port/attack?key={key}&method={method}&time={time}&port={port}&host={host}
  http://localhost:port/methods?key={key}
  http://localhost:port/reload?key={key}

Variables:
  {method} > the method name that needs to get send (gets replaced from the methods.json file)
  {checksum} > gets the host of the url (URL ONLY)
  {time} > replaces time that needs to get send
  {port} > replaces the port that needs to get send
  {host} > replaces the ip that needs to get send

Config:
  Case: "upper", "lower" and "normal"
  Key: API Key for the funnel itself
  Webhook: webhook url for discord notifies
  Regex: checks if it's a valid url or ip (can be adjusted if you don't want urls to work for example)
  Blacklists: blacklisted targets